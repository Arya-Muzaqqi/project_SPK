<?php
include 'koneksi.php';
$pengembang = $_GET['pengembang'];
$sql = "DELETE FROM saw_penilaian WHERE pengembang='$pengembang'";
$hasil = $conn->query($sql);
echo "<script>
window.location.href='penilaian.php';
alert('berhasil di hapus !'); 
</script>";
