<!doctype html>
<html lang="en">

<?php
include 'components/head.php';
?>

<body>

    <div class="wrapper d-flex align-items-stretch">
        <?php
        include 'components/sidebar.php';
        ?>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5">

            <!-- navbar  -->
            <?php
                include 'components/navbar.php';
            ?>
                
            <section id="main-content">
                <section class="wrapper">
                    <!--overview start-->
                    <div class="row">
                        <div class="col-lg-12">
                            <ol class="breadcrumb">
                                <li><i class="fas fa-fw fa-table"></i><a href="laporan.php"> Laporan Perangkingan</a></li>
                            </ol>
                        </div>
                    </div>
                   
                    <div class="container">
                        <a href="export_lap_3.php" class="btn btn-info">
                            <i class="fa fa-print"></i> 
                            <class="sr-only"> Export Data
                        </a><br><br>                                             
                            <div>
                                <b>
                                    <h6><b>NILAI PREFERENSI</b></h6>
                                </b>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><i class=""></i> No</th>
                                            <th><i class=""></i> Seri Laptop</th>
                                            <th><i class=""></i> Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        include 'koneksi.php';

                                        // Biaya
                                        $sql = "SELECT*FROM saw_penilaian ORDER BY harga ASC";
                                        $hasil = $conn->query($sql);
                                        $row = $hasil->fetch_row();
                                        $C1 = $row[1];
                                        
                                        $sql = "SELECT*FROM saw_penilaian ORDER BY ukuran ASC";
                                        $hasil = $conn->query($sql);
                                        $row = $hasil->fetch_row();
                                        $C2 = $row[2];
                                        // End Biaya
                                        
                                        $sql = "SELECT*FROM saw_penilaian ORDER BY processor DESC";
                                        $hasil = $conn->query($sql);
                                        $row = $hasil->fetch_row();
                                        $C3 = $row[3];

                                        $sql = "SELECT*FROM saw_penilaian ORDER BY ram DESC";
                                        $hasil = $conn->query($sql);
                                        $row = $hasil->fetch_row();
                                        $C4 = $row[4];

                                        $sql = "SELECT*FROM saw_penilaian ORDER BY storage DESC";
                                        $hasil = $conn->query($sql);
                                        $row = $hasil->fetch_row();
                                        $C5 = $row[5];

                                        $b = 0;
                                        $B1 = '';
                                        $B2 = '';
                                        $B3 = '';
                                        $B4 = '';
                                        $B5 = '';
                                        $B6 = '';
                                        $nilai = '';
                                        $nama = '';
                                        $x = 0;
                                        $sql = "SELECT * FROM saw_kriteria";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            $row = $hasil->fetch_row();
                                            $B1 = $row[1];
                                            $B2 = $row[2];
                                            $B3 = $row[3];
                                            $B4 = $row[4];
                                            $B5 = $row[5];
                                        }
                                        $sql = "TRUNCATE TABLE saw_perankingan";
                                        $hasil = $conn->query($sql);

                                        $sql = "SELECT * FROM saw_penilaian";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            while ($row = $hasil->fetch_row()) {
                                                $nilai = round((($C1 / $row[1]) * $B1) +
                                                    (($C2 / $row[2]) * $B2) +
                                                    (($row[3] / $C3) * $B3) +
                                                    (($row[4] / $C4) * $B4) +
                                                    (($row[5] / $C5) * $B5), 3);
                                                $nama = $row[0];
                                                $sql1 = "INSERT INTO saw_perankingan(nama,nilai_akhir) VALUES ('" . $nama . "','" . $nilai . "')";
                                                $hasil1 = $conn->query($sql1);
                                            }
                                        }
                                        $sql = "SELECT * FROM saw_perankingan";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            while ($row = $hasil->fetch_row()) {
                                        ?>
                                                <tr>
                                                    <td>&nbsp&nbsp <?php echo $b = $b + 1; ?></td>
                                                    <td><?= $row[1] ?></td>
                                                    <td><?= $row[2] ?></td>
                                                </tr>
                                        <?php }
                                        } else {
                                            echo "<tr>
                                                <td>Data Tidak Ada</td>
                                            <tr>";
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                            <div>
                                <b>
                                    <h6><b>PERANKINGAN</b></h6>
                                </b>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><i class=""></i> No</th>
                                            <th><i class=""></i> Seri Laptop</th>
                                            <th><i class="fa fa-arrow-up"></i> Nilai</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $b = 0;
                                        $sql = "SELECT*FROM saw_perankingan ORDER BY nilai_akhir DESC";
                                        $hasil = $conn->query($sql);
                                        if ($hasil->num_rows > 0) {
                                            while ($row = $hasil->fetch_row()) {
                                        ?>
                                                <tr>
                                                    <td>&nbsp&nbsp <?php echo $b = $b + 1; ?></td>
                                                    <td><?= $row[1] ?></td>
                                                    <td><?= $row[2] ?></td>
                                                </tr>
                                        <?php }
                                        } else {
                                            echo "<tr>
                                                <td>Data Tidak Ada</td>
                                            <tr>";
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </section>
            </section>
        </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>