<?php
if ($_POST) {

	include_once 'process_login.php';
	$login = new Login($db);

	$login->emailid = $_POST['email'];
	$login->passid = md5($_POST['password']);

	if ($login->login()) {
		echo "<script>location.href='home.php'</script>";
	} else {
		echo "<script>alert('Gagal Total')</script>";
	}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>K6 - Login</title>

	<!-- Custom fonts for this template-->
	<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

	<!-- Custom styles for this template-->
	<link href="css/sb-admin-2.min.css" rel="stylesheet">
	<style>
		.mySlides {
			display: none;
		}
	</style>
</head>

<body style="background: #ffffff url(images/back1.jpg)">
	<nav class="navbar navbar-inverse navbar-static-top">
		<div class="container">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<br>
				<h3 class="fa fa-solid fa-laptop"> REKOMENDASI LAPTOP TERBAIK</h3>
			</div>
		</div><!-- /.container-fluid -->
	</nav>

	<div class="container">
		<div class="row justify-content-center">
			<div class="col-xl-10 col-lg-12 col-md-9">
				<div class="card o-hidden border-0 shadow-lg my-5">
					<div class="card-body p-0">
						<div class="row">
							<div class="col-lg-6 d-none d-lg-block">
								<img class="mySlides" src="images/pexels-medhat-ayad-383568.jpg" style="width:auto">
								<img class="mySlides" src="images/andras-vas-Bd7gNnWJBkU-unsplash.jpg" style="width:auto">
								<img class="mySlides" src="images/joshua-reddekopp-SyYmXSDnJ54-unsplash.jpg" style="width:auto">
							</div>
							<div class="col-lg-6">
								<div class="p-5">
									<div class="text-center">
										<h1 class="h4 text-gray-900 mb-4">Selamat Datang!</h1>
									</div>
									<br><br>
									<form class="user" method="post">
										<div class="form-group">
											<input type="text" class="form-control form-control-user" name="email" id="InputEmail1" placeholder="Email">
										</div>
										<div class="form-group">
											<input type="password" class="form-control form-control-user" name="password" id="InputPassword1" placeholder="Password">
										</div>
										<br><br>
										<button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
									</form>
									<hr>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->

	<!-- Bootstrap core JavaScript-->
	<script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Core plugin JavaScript-->
	<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Custom scripts for all pages-->
	<script src="js/sb-admin-2.min.js"></script>

	<script>
		var myIndex = 0;
		carousel();

		function carousel() {
			var i;
			var x = document.getElementsByClassName("mySlides");
			for (i = 0; i < x.length; i++) {
				x[i].style.display = "none";
			}
			myIndex++;
			if (myIndex > x.length) {
				myIndex = 1
			}
			x[myIndex - 1].style.display = "block";
			setTimeout(carousel, 2000); // Change image every 2 seconds
		}
	</script>

</body>

</html>