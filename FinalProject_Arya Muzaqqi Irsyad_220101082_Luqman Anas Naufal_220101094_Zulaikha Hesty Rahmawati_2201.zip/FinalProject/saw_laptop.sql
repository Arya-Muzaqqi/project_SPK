-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2024 at 07:21 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saw_laptop`
--

-- --------------------------------------------------------

--
-- Table structure for table `saw_kriteria`
--

CREATE TABLE `saw_kriteria` (
  `no` int(11) NOT NULL,
  `harga` float NOT NULL,
  `ukuran` float NOT NULL,
  `processor` float NOT NULL,
  `ram` float NOT NULL,
  `storage` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `saw_kriteria`
--

INSERT INTO `saw_kriteria` (`no`, `harga`, `ukuran`, `processor`, `ram`, `storage`) VALUES
(15, 0.14, 0.21, 0.14, 0.29, 0.21);

-- --------------------------------------------------------

--
-- Table structure for table `saw_laptop`
--

CREATE TABLE `saw_laptop` (
  `nama` varchar(100) NOT NULL,
  `pengembang` varchar(100) NOT NULL,
  `kategori` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `saw_laptop`
--

INSERT INTO `saw_laptop` (`nama`, `pengembang`, `kategori`) VALUES
('MSI', 'Bravo 13', 'Gaming'),
('Lenovo', 'ideapad 3', 'Gaming'),
('Lenovo', 'ideapad 5', 'Gaming'),
('Acer', 'Nitro 3', 'Gaming'),
('Acer', 'Nitro 5', 'Gaming'),
('Hp', 'Pavilion', 'Gaming'),
('Asus', 'ROG 3', 'Gaming'),
('Asus', 'ROG 5', 'Gaming');

-- --------------------------------------------------------

--
-- Table structure for table `saw_penilaian`
--

CREATE TABLE `saw_penilaian` (
  `pengembang` varchar(100) NOT NULL,
  `harga` float NOT NULL,
  `ukuran` float NOT NULL,
  `processor` float NOT NULL,
  `ram` float NOT NULL,
  `storage` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `saw_penilaian`
--

INSERT INTO `saw_penilaian` (`pengembang`, `harga`, `ukuran`, `processor`, `ram`, `storage`) VALUES
('Bravo 13', 7500000, 1, 1, 1, 1),
('ideapad 3', 8500000, 5, 2, 3, 2),
('ideapad 5', 8000000, 4, 2, 1, 1),
('Nitro 5', 7500000, 4, 2, 4, 2),
('Pavilion', 9000000, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `saw_perankingan`
--

CREATE TABLE `saw_perankingan` (
  `no` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nilai_akhir` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `saw_perankingan`
--

INSERT INTO `saw_perankingan` (`no`, `nama`, `nilai_akhir`) VALUES
(1, 'Bravo 13', 0.598),
(2, 'ideapad 3', 0.733),
(3, 'ideapad 5', 0.501),
(4, 'Nitro 5', 0.833),
(5, 'Pavilion', 0.574);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `image`, `password`, `role_id`) VALUES
(1, 'Kelompok 6', 'laptop@gmail.com', '', '1234', 'admin'),
(2, 'member', 'member@gmail.com', '', '123', 'member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `saw_kriteria`
--
ALTER TABLE `saw_kriteria`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `saw_laptop`
--
ALTER TABLE `saw_laptop`
  ADD PRIMARY KEY (`pengembang`);

--
-- Indexes for table `saw_penilaian`
--
ALTER TABLE `saw_penilaian`
  ADD PRIMARY KEY (`pengembang`);

--
-- Indexes for table `saw_perankingan`
--
ALTER TABLE `saw_perankingan`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `saw_kriteria`
--
ALTER TABLE `saw_kriteria`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `saw_perankingan`
--
ALTER TABLE `saw_perankingan`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
