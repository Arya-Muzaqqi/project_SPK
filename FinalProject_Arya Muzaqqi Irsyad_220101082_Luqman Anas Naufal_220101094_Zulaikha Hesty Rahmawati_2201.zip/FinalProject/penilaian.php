<!doctype html>
<html lang="en">

<?php
include 'components/head.php';
?>

<body>

  <div class="wrapper d-flex align-items-stretch">
    <?php
    include 'components/sidebar.php';
    ?>

    <!-- Page Content  -->
    <div id="content" class="p-4 p-md-5">

      <?php
      include 'components/navbar.php';
      ?>

      <section id="main-content">
        <section class="wrapper">
          <!--overview start-->
          <div class="row">
            <div class="col-lg-12">
              <ol class="breadcrumb">
                <li><i class="fa fa-list-ol"></i><a href="penilaian.php"> Penilaian</a></li>
              </ol>
            </div>
          </div>

          <!--START SCRIPT INSERT-->
          <?php

          include 'koneksi.php';

          if (isset($_POST['submit'])) {
            $pengembang = $_POST['pengembang'];
            $harga = $_POST['harga'];
            $ukuran = substr($_POST['ukuran'], 1, 1);
            $processor = substr($_POST['processor'], 1, 1);
            $ram = substr($_POST['ram'], 1, 1);
            $storage = substr($_POST['storage'], 1, 1);
            if ($harga == "" || $ukuran == "" || $processor == "" || $ram == "" || $storage == "" || $harga == "") {
              echo "<script>
              alert('Tolong Lengkapi Data yang Ada!');
              </script>";
            } else {
              $sql = "SELECT*FROM saw_penilaian WHERE pengembang='$pengembang'";
              $hasil = $conn->query($sql);
              $rows = $hasil->num_rows;
              if ($rows > 0) {
                $row = $hasil->fetch_row();
                echo "<script>
                alert('Laptop seri $pengembang sudah ada!');
                </script>";
              } else {
                //insert name
                $sql = "INSERT INTO saw_penilaian(
                pengembang,harga,ukuran,processor,ram,storage)
                values ('" . $pengembang . "',
                '" . $harga . "',
                '" . $ukuran . "',
                '" . $processor . "',
                '" . $ram . "',
                '" . $storage . "')";
                $hasil = $conn->query($sql);
                echo "<script>
                alert('Penilaian Berhasil di Tambahkan!');
                </script>";
              }
            }
          }
          ?>
          <!-- END SCRIPT INSERT-->

          <!--start inputan-->
          <form method="POST" action="">
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Seri Laptop</label>
              <div class="col-sm-4">
                <select class="form-control" name="pengembang">
                  <?php
                  //load nama
                  $sql = "SELECT * FROM saw_laptop";
                  $hasil = $conn->query($sql);
                  $rows = $hasil->num_rows;
                  if ($rows > 0) {
                    while ($row = mysqli_fetch_array($hasil)) :; {
                      } ?> <option><?php echo $row[1]; ?></option>
                  <?php endwhile;
                  } ?>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Harga</label>
              <div class="col-sm-4">
                <input type="text" class="form-control" name="harga" id="harga">
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Ukuran</label>
              <div class="col-sm-4">
                <select class=" form-control" name="ukuran">
                  <option>(1) Sangat Kecil</option>
                  <option>(2) Kecil</option>
                  <option>(3) Sedang</option>
                  <option>(4) Besar</option>
                  <option>(5) Sangat Besar</option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Processor</label>
              <div class="col-sm-4">
                <select class=" form-control" name="processor">
                  <option>(1) Sangat Buruk</option>
                  <option>(2) Buruk</option>
                  <option>(3) Sedang</option>
                  <option>(4) Baik</option>
                  <option>(5) Sangat Baik</option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">RAM</label>
              <div class="col-sm-4">
                <select class=" form-control" name="ram">
                  <option>(1) Sangat Kecil</option>
                  <option>(2) Kecil</option>
                  <option>(3) Sedang</option>
                  <option>(4) Besar</option>
                  <option>(5) Sangat Besar</option>
                </select>
              </div>
            </div>
            <div class="form-group row">
              <label class="col-sm-2 col-form-label">Storage</label>
              <div class="col-sm-4">
                <select class=" form-control" name="storage">
                  <option>(1) Sangat Kecil</option>
                  <option>(2) Kecil</option>
                  <option>(3) Sedang</option>
                  <option>(4) Besar</option>
                  <option>(5) Sangat Besar</option>
                </select>
              </div>
            </div>
            <div class="mb-4">
              <button type="submit" name="submit" class="btn btn-outline-primary"><i class="fa fa-save"></i> Submit</button>
              <a href="export_penilaian.php" class="btn btn-info">
                <i class="fa fa-print"></i> 
                <class="sr-only"> Export Data
              </a>
            </div>
          </form>
          <div class="container">
          <table class="table" id="mauexport">
            <thead>
              <tr>
                <th><i class=""></i> No</th>
                <th><i class=""></i> Seri Laptop</th>
                <th><i class="fa fa-arrow-down"></i> Harga</th>
                <th><i class="fa fa-arrow-down"></i> Ukuran</th>
                <th><i class="fa fa-arrow-up"></i> Processor</th>
                <th><i class="fa fa-arrow-up"></i> RAM</th>
                <th><i class="fa fa-arrow-up"></i> Storage</th>
                <th><i class="fa fa-cogs"></i> Opsi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $b = 0;
              $sql = "SELECT*FROM saw_penilaian ORDER BY pengembang ASC";
              $hasil = $conn->query($sql);
              $rows = $hasil->num_rows;
              if ($rows > 0) {
                while ($row = $hasil->fetch_row()) {
              ?>
                  <tr>
                    <td align="center"><?php echo $b = $b + 1; ?></td>
                    <td><?= $row[0] ?></td>
                    <td align="center"><?= $row[1] ?></td>
                    <td align="center"><?= $row[2] ?></td>
                    <td align="center"><?= $row[3] ?></td>
                    <td align="center"><?= $row[4] ?></td>
                    <td align="center"><?= $row[5] ?></td>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-danger" href="penilaian_hapus.php?pengembang=<?= $row[0] ?>">
                          <i class="fa fa-close"></i></a>
                      </div>
                    </td>
                  </tr>
              <?php }
              } else {
                echo "<tr>
                    <td>Data Tidak Ada</td>
                <tr>";
              } ?>
            </tbody>
          </table>
          </div>
        </section>
      </section>
    </div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
</body>
</html>