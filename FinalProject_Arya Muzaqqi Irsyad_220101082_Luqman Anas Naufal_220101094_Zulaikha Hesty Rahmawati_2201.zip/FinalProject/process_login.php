<?php
session_start();
include 'koneksi.php';

$email = $_POST['email'];
$password = $_POST['password'];

$login =mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$password'");
$cek = mysqli_num_rows($login);

if($cek > 0){

	$data = mysqli_fetch_assoc($login);
	echo $data['role_id'];
	session_start();
	$_SESSION['is_logged']=true;

	// cek jika user login sebagai admin
	if($data['role_id']=="admin"){

		// buat session login dan username
		$_SESSION['email'] = $email;
		$_SESSION['role_id'] = "admin";
		// alihkan ke halaman dashboard admin
		header("location:../home.php");

	// cek jika user login sebagai warga
	}else if($data['role_id']=="member"){
		// buat session login dan username
		$_SESSION['email'] = $email;
		$_SESSION['role_id'] = "member";
		// alihkan ke halaman dashboard warga
		header("location:../index_member.php");
	}else{

		// alihkan ke halaman login kembali
		// header("location:login.php?pesan=gagal");
		echo "salah";
	}	
}else{
	header("location:../login.php?pesan=gagal");
}

