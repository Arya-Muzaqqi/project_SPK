<!doctype html>
<html lang="en">

<?php
include 'components/head.php';
?>

<body>

  <div class="wrapper d-flex align-items-stretch">
    <?php
    include 'components/sidebar.php';
    ?>

    <!-- Page Content  -->
    <div id="content" class="p-4 p-md-5">

      <?php
      include 'components/navbar.php';
      ?>

      <section id="main-content">
        <section class="wrapper">
          <!--overview start-->
          <div class="row">
            <div class="col-lg-12">
              <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="home.php"> Dashboard</a></li>
              </ol>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <h3 align="center"><strong style="font-size: 30px">Selamat Datang <br> Di Sistem Rekomendasi Laptop Terbaik</strong> </h3>
            </div>
            <div class="col-lg-6 d-none d-lg-block">
              <img class="mySlides" src="images/clayton-malquist-P2iaN5Kqk-4-unsplash.jpg" style="width:auto">
              <img class="mySlides" src="images/nikolay-u76CN5rZeOU-unsplash.jpg" style="width:auto">
              <img class="mySlides" src="images/ash-edmonds-Koxa-GX_5zs-unsplash.jpg" style="width:auto">
            </div>
          </div>
        </section>
      </section>
    </div>
  </div>

  <script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script>
    var myIndex = 0;
    carousel();

    function carousel() {
      var i;
      var x = document.getElementsByClassName("mySlides");
      for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
      }
      myIndex++;
      if (myIndex > x.length) {
        myIndex = 1
      }
      x[myIndex - 1].style.display = "block";
      setTimeout(carousel, 5000); // Change image every 5 seconds
    }
  </script>
</body>

</html>