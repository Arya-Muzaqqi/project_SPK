<!doctype html>
<html lang="en">

<?php
include 'components/head.php';
?>

<body>

    <div class="wrapper d-flex align-items-stretch">
        <?php
        include 'components/sidebar.php';
        ?>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5">

            <!-- navbar  -->
            <?php
                include 'components/navbar.php';
            ?>
                
            <section id="main-content">
                <section class="wrapper">
                    <!--overview start-->
                    <div class="row">
                        <div class="col-lg-12">
                            <ol class="breadcrumb">
                                <li><i class="fas fa-fw fa-table"></i><a href="laporan.php"> Laporan Normalisasi</a></li>
                            </ol>
                        </div>
                    </div>
                   
                    <div class="container">
                        <a href="export_lap_2.php" class="btn btn-info">
                            <i class="fa fa-print"></i> 
                            <class="sr-only"> Export Data
                        </a><br><br>
                            <div>
                                <b>
                                    <h6><b>NORMALISASI</b></h6>
                                </b>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><i class=""></i> No</th>
                                            <th><i class=""></i> Seri Laptop</th>
                                            <th><i class="fa fa-arrow-down"></i> Harga</th>
                                            <th><i class="fa fa-arrow-down"></i> Ukuran Laptop</th>
                                            <th><i class="fa fa-arrow-up"></i> Processor</th>
                                            <th><i class="fa fa-arrow-up"></i> RAM</th>
                                            <th><i class="fa fa-arrow-up"></i> Storage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        include 'koneksi.php';
                                        $sql = "SELECT*FROM saw_penilaian";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            $b = 0;
                                            $C1 = '';
                                            $C2 = '';
                                            $C3 = '';
                                            $C4 = '';
                                            $C5 = '';

                                            // Biaya
                                            $sql = "SELECT*FROM saw_penilaian ORDER BY harga ASC";
                                            $hasil = $conn->query($sql);
                                            $row = $hasil->fetch_row();
                                            $C1 = $row[1];
                                            
                                            $sql = "SELECT*FROM saw_penilaian ORDER BY ukuran ASC";
                                            $hasil = $conn->query($sql);
                                            $row = $hasil->fetch_row();
                                            $C2 = $row[2];
                                            // End Biaya
                                            
                                            $sql = "SELECT*FROM saw_penilaian ORDER BY processor DESC";
                                            $hasil = $conn->query($sql);
                                            $row = $hasil->fetch_row();
                                            $C3 = $row[3];

                                            $sql = "SELECT*FROM saw_penilaian ORDER BY ram DESC";
                                            $hasil = $conn->query($sql);
                                            $row = $hasil->fetch_row();
                                            $C4 = $row[4];

                                            $sql = "SELECT*FROM saw_penilaian ORDER BY storage DESC";
                                            $hasil = $conn->query($sql);
                                            $row = $hasil->fetch_row();
                                            $C5 = $row[5];

                                        } else {
                                            echo "<tr>
                                                <td>Data Tidak Ada</td>
                                            <tr>";
                                        }

                                        $sql = "SELECT*FROM saw_penilaian";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            while ($row = $hasil->fetch_row()) {
                                        ?>
                                                <tr>
                                                    <td align="center"><?php echo $b = $b + 1; ?></td>
                                                    <td><?= $row[0] ?></td>
                                                    <td align="center"><?= round($C1 / $row[1], 2) ?></td>
                                                    <td align="center"><?= round($C2 / $row[2], 2) ?></td>
                                                    <td align="center"><?= round($row[3] / $C3, 2) ?></td>
                                                    <td align="center"><?= round($row[4] / $C4, 2) ?></td>
                                                    <td align="center"><?= round($row[5] / $C5, 2) ?></td>
                                                </tr>
                                        <?php }
                                        }  ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </section>
            </section>
        </div>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>