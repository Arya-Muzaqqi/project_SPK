<!doctype html>
<html lang="en">

<?php
include 'components/head.php';
?>

<body>

    <div class="wrapper d-flex align-items-stretch">
        <?php
        include 'components/sidebar.php';
        ?>

        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5">

            <!-- navbar  -->
            <?php
                include 'components/navbar.php';
            ?>
                
            <section id="main-content">
                <section class="wrapper">
                    <!--overview start-->
                    <div class="row">
                        <div class="col-lg-12">
                            <ol class="breadcrumb">
                                <li><i class="fas fa-fw fa-table"></i><a href="laporan.php"> Laporan Perhitungan</a></li>
                            </ol>
                        </div>
                    </div>
                   
                    <div class="container">
                        <a href="export_lap_1.php" class="btn btn-info">
                            <i class="fa fa-print"></i> 
                            <class="sr-only"> Export Data
                        </a><br><br>
                            <div>
                                <b>
                                    <h6><b>PERHITUNGAN</b></h6>
                                </b>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th><i class=""></i> No</th>
                                            <th><i class=""></i> Seri Laptop</th>
                                            <th><i class="fa fa-arrow-down"></i> Harga</th>
                                            <th><i class="fa fa-arrow-down"></i> Ukuran Laptop</th>
                                            <th><i class="fa fa-arrow-up"></i> Processor</th>
                                            <th><i class="fa fa-arrow-up"></i> RAM</th>
                                            <th><i class="fa fa-arrow-up"></i> Storage</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        include 'koneksi.php';

                                        $b = 0;
                                        $sql = "SELECT*FROM saw_penilaian ORDER BY pengembang ASC";
                                        $hasil = $conn->query($sql);
                                        $rows = $hasil->num_rows;
                                        if ($rows > 0) {
                                            while ($row = $hasil->fetch_row()) {
                                        ?>
                                                <tr>
                                                    <td align="center"><?php echo $b = $b + 1; ?></td>
                                                    <td><?= $row[0] ?></td>
                                                    <td align="center"><?= $row[1] ?></td>
                                                    <td align="center"><?= $row[2] ?></td>
                                                    <td align="center"><?= $row[3] ?></td>
                                                    <td align="center"><?= $row[4] ?></td>
                                                    <td align="center"><?= $row[5] ?></td>
                                                </tr>
                                        <?php }
                                        } else {
                                            echo "<tr>
                                                <td>Data Tidak Ada</td>
                                            <tr>";
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                    </div>
                </section>
            </section>
        </div>
    </div>
    
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>